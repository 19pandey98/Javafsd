package example9;
interface Animal {
	 default void speak() {
	     System.out.println("Animal speaks");
	 }
	}


	interface Dog extends Animal {
	 default void speak() {
	     System.out.println("Dog will bark");
	 }
	}

	interface Cat extends Animal {
	 default void speak() {
	     System.out.println("Cat will roar");
	 }
	}

	//Create a class that implements both Dog and Cat interfaces
	class Pet implements Dog, Cat {
	 // To resolve the diamond problem, override the conflicting default method
	 @Override
	 public void speak() {
	     Dog.super.speak(); // Call the speak method from the Dog interface
	     Cat.super.speak(); // Call the speak method from the Cat interface
	 }
	}

	public class Pets {
	 public static void main(String[] args) {
	     Pet myPet = new Pet();
	     myPet.speak(); // Calls the overridden speak method in the Pet class
	 }

}
