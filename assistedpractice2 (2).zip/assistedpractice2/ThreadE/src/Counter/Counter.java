package Counter;

public class Counter {
 public static void main(String[] args) {
	        Counter counter = new Counter();

	        // Create multiple threads
	        IncrementThread thread1 = new IncrementThread(counter);
	        IncrementThread thread2 = new IncrementThread(counter);

	        // Start the threads
	        thread1.start();
	        thread2.start();
	    }
	}
}
