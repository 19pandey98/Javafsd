/**
 * 
 */
/**
 * 
 */
module ThreadE {
	requires Example;
}