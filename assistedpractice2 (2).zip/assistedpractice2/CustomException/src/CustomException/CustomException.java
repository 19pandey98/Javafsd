package CustomException;

public class CustomException {
	public static void main(String args[]) {
	    try {
	        // Code that may raise an exception
	        int data = 100 / 0;
	        // Rest of the code here (will not be executed if an exception occurs)
	        System.out.println("This line will not be reached.");
	    } catch (ArithmeticException e) {
	        // Handle the exception
	        System.out.println("An ArithmeticException occurred: " + e.getMessage());
	    }
	    // The program can continue with the rest of the code
	    System.out.println("Rest of the code...");
	}

	
}
