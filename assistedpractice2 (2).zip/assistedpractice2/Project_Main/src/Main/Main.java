package Main;

public class Main {
	  public static void main(String[] args) {
	        // Create and start a thread using a lambda expression
	        Thread thread = new Thread(() -> {
	            for (int i = 1; i <= 9; i++) {
	                System.out.println("Thread using lambda: " + i);
	            }
	        });
	        thread.start();
	    }
}



