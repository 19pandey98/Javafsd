package Pragati;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/SessionTrackingWithURLRewrite")
public class SessionTracking extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Get the session object
        HttpSession session = request.getSession();

        // Set session attribute for visit count
        Integer visitCount = (Integer) session.getAttribute("visitCount");
        if (visitCount == null) {
            visitCount = 1;
        } else {
            visitCount++;
        }
        session.setAttribute("visitCount", visitCount);

        // Set the response content type
        response.setContentType("text/html");

        // Get a PrintWriter to write HTML response
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Session Tracking with URL Rewriting</title></head><body>");
        out.println("<h1>Session Tracking with URL Rewriting</h1>");
        out.println("<p>Session ID: " + session.getId() + "</p>");
        out.println("<p>Number of visits: " + visitCount + "</p>");
        out.println("<p><a href='" + response.encodeURL(request.getRequestURI()) + "'>Refresh</a></p>");
        out.println("</body></html>");
    }
}
