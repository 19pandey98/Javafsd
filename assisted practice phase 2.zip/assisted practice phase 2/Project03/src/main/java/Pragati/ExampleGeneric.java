package Pragati;
import java.io.*;


import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class ExampleGeneric extends GenericServlet{
 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public void service(ServletRequest req,ServletResponse res)
throws IOException,ServletException{
   res.setContentType("text/html");
   PrintWriter pwriter=res.getWriter();
   pwriter.print("<html>");
   pwriter.print("<body>");
   pwriter.print("<h2>Generic Servlet Example</h2>");
   pwriter.print("<p>Hello BeginnersBook Readers!</p>");
   pwriter.print("</body>");
   pwriter.print("</html>");
}
}

