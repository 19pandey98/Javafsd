package pragathi01;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class User {
    private String username;
    private String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String newPassword) {
        this.password = newPassword;
    }
}

class Budget {
    private int month;
    private double budgetAmount;
    private List<Expense> expenses;

    public Budget(int month, double budgetAmount) {
        this.month = month;
        this.budgetAmount = budgetAmount;
        this.expenses = new ArrayList<>();
    }

    public int getMonth() {
        return month;
    }

    public double getBudgetAmount() {
        return budgetAmount;
    }

    public List<Expense> getExpenses() {
        return expenses;
    }

    public void addExpense(Expense expense) {
        expenses.add(expense);
    }

    public double getTotalBudget() {
        double totalExpenses = expenses.stream().mapToDouble(Expense::getAmount).sum();
        return budgetAmount - totalExpenses;
    }

    public void deleteBudgetLogs(int month, int year) {
        expenses.removeIf(expense -> {
            String[] dateParts = expense.getDate().split("-");
            int expMonth = Integer.parseInt(dateParts[1]);
            int expYear = Integer.parseInt(dateParts[0]);
            return expMonth == month && expYear == year;
        });
    }
}

class Expense {
    private String type;
    private double amount;
    private String date;

    public Expense(String type, double amount, String date) {
        this.type = type;
        this.amount = amount;
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public double getAmount() {
        return amount;
    }

    public String getDate() {
        return date;
    }
}



        public class BudgetManagementApp {
            public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);
                User user = new User("praga123", "pandey123");
                Budget budget = null;
               while (true) {
                    System.out.println("WELCOME TO BUDGET TRACKER APP");
                    System.out.println("PLEASE LOGIN TO CONTINUE -");
                   

                while (true) {
                    System.out.println("Choose an action:");
                    System.out.println("1. Log in");
                    System.out.println("2. Set a monthly budget");
                    System.out.println("3. Record an expense");
                    System.out.println("4. Budgetary logs");
                    System.out.println("5. Date-wise logs");
                    System.out.println("6. Month-wise log");
                    System.out.println("7. Total budget");
                    System.out.println("8. Delete budgetary logs");
                    System.out.println("9. Change the password");
                    System.out.println("0. Exit");
                    System.out.print("Enter your choice: ");
                    
                    int choice = scanner.nextInt();
                    
                    switch (choice) {
                        case 1:
                            // Log in
                            System.out.print("Enter username: ");
                            String enteredUsername = scanner.next();
                            System.out.print("Enter password: ");
                            String enteredPassword = scanner.next();
                            if (user.getUsername().equals(enteredUsername) && user.getPassword().equals(enteredPassword)) {
                                System.out.println("Login successful.");
                            } else {
                                System.out.println("Login failed. Invalid username or password.");
                            }
                            break;
                        case 2:
                              System.out.println("MONTHLY BUDGET IS ALREADY SET.");
                                  System.out.print("Do you want to update it? (Y: YES | N: NO): ");
                                  String updateChoice = scanner.next();
                                  // Set a monthly budget
                                  System.out.print("Enter the month (1-12): ");
                                  int month = scanner.nextInt();
                                  System.out.print("Enter the budget amount: ");
                                  double budgetAmount = scanner.nextDouble();
                                  budget = new Budget(month, budgetAmount);
                                  System.out.println("Budget set successfully.");
                                  break;

                        case 3:
                            // Record an expense
                            if (budget != null) {
                                // Get the expense category, amount, and password from the user
                                System.out.println("CHOOSE THE EXPENSE CATEGORY");
                                System.out.println("1. CLOTHES");
                                System.out.println("2. ELECTRICITY BILL");
                                System.out.println("3. EXAM FEES");
                                System.out.println("4. FOOD");
                                System.out.println("5. FUEL");
                                System.out.println("6. HOUSE RENT");
                                System.out.println("7. TRAVELLING");
                                System.out.println("8. OTHER");
                                System.out.print("Enter the category (1-8): ");
                                int categoryChoice = scanner.nextInt();

                                String[] categories = {
                                    "CLOTHES",
                                    "ELECTRICITY BILL",
                                    "EXAM FEES",
                                    "FOOD",
                                    "FUEL",
                                    "HOUSE RENT",
                                    "TRAVELLING",
                                    "OTHER"
                                };

                                if (categoryChoice >= 1 && categoryChoice <= 8) {
                                    String category = categories[categoryChoice - 1];
                                    System.out.print("ENTER EXPENSE AMOUNT: ");
                                    double expenseAmount = scanner.nextDouble();
                                    System.out.print("ENTER YOUR PASSWORD: "); // You can reuse enteredPassword here
                                    enteredPassword = scanner.next();

                                    if (user.getPassword().equals(enteredPassword)) {
                                        System.out.println("EXPENSE RECORDED SUCCESSFULLY.");
                                        String currentDate = java.time.LocalDate.now().toString();
                                        Expense expense = new Expense(category, expenseAmount, currentDate);
                                        budget.addExpense(expense);
                                    } else {
                                        System.out.println("Invalid password. Expense not recorded.");
                                    }
                                } else {
                                    System.out.println("Invalid category choice.");
                                }
                            } else {
                                System.out.println("Budget is not set. Please set a budget first.");
                            }
                            break;

                        case 4:
                            // Budgetary logs
                            if (budget != null) {
                                List<Expense> expenses = budget.getExpenses();
                                for (Expense expense : expenses) {
                                    System.out.println("Type: " + expense.getType());
                                    System.out.println("Amount: " + expense.getAmount());
                                    System.out.println("Date: " + expense.getDate());
                                    System.out.println("--------");
                                }
                            } else {
                                System.out.println("Budget is not set. Please set a budget first.");
                            }
                            break;
                        
             case 5:
                // Date-wise logs
                if (budget != null) {
                    System.out.print("Enter the date (YYYY-MM-DD): ");
                    String date = scanner.next();
                    List<Expense> dateWiseExpenses = new ArrayList<>();
                    for (Expense expense : budget.getExpenses()) {
                        if (expense.getDate().equals(date)) {
                            dateWiseExpenses.add(expense);
                        }
                    }
                    if (!dateWiseExpenses.isEmpty()) {
                        for (Expense expense : dateWiseExpenses) {
                            System.out.println("Type: " + expense.getType());
                            System.out.println("Amount: " + expense.getAmount());
                            System.out.println("Date: " + expense.getDate());
                            System.out.println("--------");
                        }
                    } else {
                        System.out.println("No expenses found for the given date.");
                    }
                } else {
                    System.out.println("Budget is not set. Please set a budget first.");
                }
                break;
            case 6:
                // Month-wise log
                if (budget != null) {
                    System.out.print("Enter the month (1-12): ");
                    int monthChoice = scanner.nextInt();
                    System.out.print("Enter the year: ");
                    int yearChoice = scanner.nextInt();
                    List<Expense> monthWiseExpenses = new ArrayList<>();
                    for (Expense expense : budget.getExpenses()) {
                        String[] dateParts = expense.getDate().split("-");
                        int expenseMonth = Integer.parseInt(dateParts[1]);
                        int expenseYear = Integer.parseInt(dateParts[0]);
                        if (expenseMonth == monthChoice && expenseYear == yearChoice) {
                            monthWiseExpenses.add(expense);
                        }
                    }
                    if (!monthWiseExpenses.isEmpty()) {
                        for (Expense expense : monthWiseExpenses) {
                            System.out.println("Type: " + expense.getType());
                            System.out.println("Amount: " + expense.getAmount());
                            System.out.println("Date: " + expense.getDate());
                            System.out.println("--------");
                        }
                    } else {
                        System.out.println("No expenses found for the given month and year.");
                    }
                } else {
                    System.out.println("Budget is not set. Please set a budget first.");
                }
                break;
            }  if (choice == 7) {
                // Total budget
                if (budget != null) {
                    double totalBudget = budget.getTotalBudget();
                    System.out.println("Total budget for the current month: " + totalBudget);
                } else {
                    System.out.println("Budget is not set. Please set a budget first.");
                }
            } else if (choice == 8) {
                // Delete budgetary logs
                if (budget != null) {
                    // Get a month and year from the user and delete budgetary logs for that month and year
                    // Implement logic for deleting budgetary logs
                } else {
                    System.out.println("Budget is not set. Please set a budget first.");
                }
            } else if (choice == 9) {
                // Change the password
                System.out.print("Enter old password: ");
                String oldPassword = scanner.next();
                if (oldPassword.equals(user.getPassword())) {
                    System.out.print("Enter new password: ");
                    String newPassword = scanner.next();
                    user.setPassword(newPassword);
                    System.out.println("Password changed successfully.");
                } else {
                    System.out.println("Invalid old password.");
                }
            } else if (choice == 0) {
            	System.out.println("exit.goodbye!");
                // Exit
                break;
            } 
        }

    }
            }
        }