/**
 * 
 */
/**
 * 
 */
module example12 {
}