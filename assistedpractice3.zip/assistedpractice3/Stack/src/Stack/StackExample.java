package Stack;
/*import java.util.*;
public class StackExample {
	 public static void main(String[] args) {
	        // Create a stack
	        Stack<Integer> stack = new Stack<>();

	        // Push (insert) elements onto the stack
	        stack.push(10);
	        stack.push(20);
	        stack.push(30);
	        stack.push(40);

	        System.out.println("Stack: " + stack);

	        // Pop (remove) elements from the stack
	        int poppedElement = stack.pop(); // Removes and returns the top element
	        System.out.println("Popped element: " + poppedElement);

	        System.out.println("Stack after pop: " +stack);
	    }
	}*/
import java.util.LinkedList;

public class StackExample {
    private LinkedList<Integer> stack;

    public StackExample() {
        stack = new LinkedList<>();
    }

    public void push(int element) {
        stack.push(element);
    }

    public int pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty. Cannot pop.");
        }
        return stack.pop();
    }

    public boolean isEmpty() {
        return stack.isEmpty();
    }

    public static void main(String[] args) {
        StackExample stackExample = new StackExample();

        stackExample.push(10);
        stackExample.push(20);
        stackExample.push(30);

        System.out.println("Popped: " + stackExample.pop());
        System.out.println("Popped: " + stackExample.pop());
        System.out.println("Is stack empty? " + stackExample.isEmpty());
    }
}
