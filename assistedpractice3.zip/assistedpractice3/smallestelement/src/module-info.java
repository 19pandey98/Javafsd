/**
 * 
 */
/**
 * 
 */
module smallestelement {
}