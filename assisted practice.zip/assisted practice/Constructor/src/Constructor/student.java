package Constructor;

public class student {
    public static void main(String[] args) {
        // Using the default constructor
        Student student1 = new Student();
        System.out.println("Student 1 - Name: " + student1.getName() + ", Age: " + student1.getAge());

        // Using the parameterized constructor
        Student student2 = new Student("Alice", 20);
        System.out.println("Student 2 - Name: " + student2.getName() + ", Age: " + student2.getAge());

        // Using constructor chaining
        Student student3 = new Student("Bob");
        System.out.println("Student 3 - Name: " + student3.getName() + ", Age: " + student3.getAge());
    }
}

	}
