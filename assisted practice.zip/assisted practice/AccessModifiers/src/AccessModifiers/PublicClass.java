package AccessModifiers;

public class PublicClass {

}
