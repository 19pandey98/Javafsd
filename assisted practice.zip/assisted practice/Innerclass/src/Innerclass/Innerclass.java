package Innerclass;

public class Innerclass {
	private String msg="Inner Classes1";
	void display(){ 
	class Inner{ 
	void msg(){
	System.out.println(msg);
	} 
 } 
	 
	 Inner l=new Inner(); 
	 l.msg(); 
} 
	public static void main(String[] args) {
	Innerclass ob=new Innerclass (); 
	ob.display();
	}


}
