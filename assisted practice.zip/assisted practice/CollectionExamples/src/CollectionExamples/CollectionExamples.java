package CollectionExamples;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;


public class CollectionExamples {
	public static void main(String[] args) {
        // ArrayList
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("grapes");
        arrayList.add("guava");
        arrayList.add("apple");

        // LinkedList
        LinkedList<String> linkedList = new LinkedList<>();
        linkedList.add("cupcake");
        linkedList.add("Cherry");
        linkedList.add("cake");

        // HashMap
        HashMap<Integer, String> hashMap = new HashMap<>();
        hashMap.put(1, "One");
        hashMap.put(2, "Two");
        hashMap.put(3, "Three");

        // HashSet
        HashSet<String> hashSet = new HashSet<>();
        hashSet.add("purple");
        hashSet.add("Green");
        hashSet.add("white");

        // Print ArrayList
        System.out.println("ArrayList:");
        for (String fruit : arrayList) {
            System.out.println(fruit);
        }

        // Print LinkedList
        System.out.println("\nLinkedList:");
        for (String animal : linkedList) {
            System.out.println(animal);
        }

        // Print HashMap
        System.out.println("\nHashMap:");
        for (int key : hashMap.keySet()) {
            System.out.println(key + " -> " + hashMap.get(key));
        }

        // Print HashSet
        System.out.println("\nHashSet:");
        Iterator<String> iterator = hashSet.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
	

}
