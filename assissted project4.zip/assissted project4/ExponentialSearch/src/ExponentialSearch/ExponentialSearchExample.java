package ExponentialSearch;
import java.util.Arrays;

public class ExponentialSearchExample {

    public static int exponentialSearch(int[] arr, int target) {
        if (arr[0] == target) {
            return 0;  // Target found at the first position
        }

        int i = 1;
        while (i < arr.length && arr[i] <= target) {
            i *= 2;  // Double the position for each iteration
        }

        // Perform binary search for the target in the appropriate range
        return Arrays.binarySearch(arr, i / 2, Math.min(i, arr.length), target);
    }

    public static void main(String[] args) {
        int[] arr = { 2, 5, 8, 12, 16, 23, 38, 45, 56, 72 };
        int target = 23;

        int result = exponentialSearch(arr, target);

        if (result >= 0) {
            System.out.println("Target " + target + " found at index " + result);
        } else {
            System.out.println("Target " + target + " is not present in the array.");
        }
    }
}


